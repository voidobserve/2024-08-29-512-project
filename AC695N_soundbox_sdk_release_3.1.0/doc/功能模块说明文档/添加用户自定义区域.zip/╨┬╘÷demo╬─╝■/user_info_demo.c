#include "includes.h"
#include "boot.h"
#include "asm/sfc_norflash_api.h"

/*
 * @brief 打开user_info区域, 并获取区域属性
 * @parm: attr, 用于获取区域属性(地址和大小);
 * @return: 区域操作句柄(使用文件接口操作)
 */
FILE *user_info_zone_init(struct vfs_attr *attr)
{
    u32 file_len;
    u32 file_addr;

    FILE *fp = NULL;
    //打开文件
    fp = fopen("mnt/sdfile/app/user", "wr"); //字符: mnt/sdfile/app/ 固定; 字符user对应ini文件里配置的名称
    if (fp) {
        printf("open succ");
    } else {
        printf("open fail!");
        return NULL;
    }

    //获取文件属性, fszie: 区域大小, sclust: 区域长度;
    fget_attrs(fp, attr);
    //地址转换
    u32 sdfile_cpu_addr2flash_addr(u32 offset);
    attr->sclust = sdfile_cpu_addr2flash_addr(attr->sclust); //将cpu地址转换为flash的物理地址, 用于擦除操作

    return fp;
}

/*
 * @brief: 擦除user_info区域, 用户根据情况执行擦除操作,
 *			demo默认擦除整块区域,
 * @notice: flash不同支持的最小擦除单位不同(page/sector),
 * @parm: fp: 在user_info_zone_init()中初始化的句柄;
 * @parm: attr: 区域属性句柄;
 * @return: 无
 */
void user_info_zone_earse(FILE *fp, struct vfs_attr *attr)
{
    u32 erase_total_size = attr->fsize;
    u32 erase_addr = attr->sclust;

    printf("erase %d @ 0x%x", erase_total_size, erase_addr);
    u32 erase_size = 4096;
    u32 erase_cmd = IOCTL_ERASE_SECTOR;
    //flash不同支持的最小擦除单位不同(page/sector)
    //boot_info.vm.align == 1: 最小擦除单位page;
    //boot_info.vm.align != 1: 最小擦除单位sector;
    if (boot_info.vm.align == 1) {
        erase_size = 256;
        erase_cmd = IOCTL_ERASE_PAGE;
    }
    while (erase_total_size) {
        //擦除区域操作
        norflash_ioctl(NULL, erase_cmd, erase_addr);
        erase_addr += erase_size;
        erase_total_size -= erase_size;
    }

    //擦除完成后把文件指针定位到科写的位置
    fseek(fp, 0, SEEK_SET);
}


/*
 * @brief: user_info任务, 用于接收要写入的buf信息,
 * 			并把该buf内容写入user_info区域;
 * @parm: priv, 任务创建时传入的参数;
 * @return: void
 */
static void user_info_zone_task(void *priv)
{
    int res;
    int msg[32];
    struct vfs_attr attr = {0}; //user_info区域属性, sclust: 区域地址, fsize: 区域大小
    FILE *user_fp; 	//区域读写句柄
    u8 *wbuf; 		//写入buf地址
    u32 wbuf_len; 	//写入buf长度
    u32 rbuf_len; 	//读长度
    u8 rbuf[50]; 	//读buf
    int ret = 0; 	//区域操作返回值

    //user_info区域初始化
    user_fp = user_info_zone_init(&attr);

    while (1) {
        res = os_task_pend("taskq", msg, ARRAY_SIZE(msg)); //等待接收要写入的buf信息
        switch (res) {
        case OS_TASKQ:
            switch (msg[0]) {
            case Q_MSG:
                wbuf = (u8 *)msg[1]; 	//要写入的buf地址
                wbuf_len = (u32)msg[2]; //要写入buf长度
                //把buf写入区域
                ret = fwrite(user_fp, wbuf, wbuf_len);
                if (ret != wbuf_len) { //write err, 所写位置不为0xFF
                    //TODO: 用户根据需求执行擦除操作
                    user_info_zone_earse(user_fp, &attr);
                    //然后再写入buf内容
                    fwrite(user_fp, wbuf, wbuf_len);
                }

                //for test: 读出刚才写入的内容, 检查是否写入正确;
                fseek(user_fp, -wbuf_len, SEEK_CUR); //把文件指针移到刚写的位置
                while (wbuf_len) {
                    rbuf_len = wbuf_len > sizeof(rbuf) ? sizeof(rbuf) : wbuf_len;
                    memset(rbuf, 0x00, rbuf_len);
                    //读出写入buf内容
                    fread(user_fp, rbuf, rbuf_len);
                    //打印写入buf内容
                    put_buf(rbuf, rbuf_len);
                    wbuf_len -= rbuf_len;
                }
                break;
            }
            break;
        default:
            break;
        }
    }
}

/*
 * @brief: 定时给user_info任务发送要写入的buf消息, 用于测试
 * @parm: void
 * @return: void
 */
void user_info_rw_timer(void)
{
    int msg[8];
    char *str = "I am test string";

    msg[0] = (int)str; 		//buf地址
    msg[1] = strlen(str); 	//buf长度
    os_taskq_post_type("user_info", Q_MSG, 2, msg); //向user_info任务发送要写入的buf消息;
}


/*
 * @brief: 创建user_info任务, 并添加一个定时器, 向该任务发送消息, 用于测试
 * @parm: void
 * @return: void
 */
void user_info_rw_test(void)
{
    //创建一个任务
    os_task_create(user_info_zone_task, NULL, 3, 256, 64, "user_info");
    //for test: 添加一个定时器, 向该任务发送消息, 10s中调用一次
    sys_timer_add(NULL, user_info_rw_timer, 10000);
}
